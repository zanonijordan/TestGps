package it.mws2018039.testgps;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/*
 * https://developers.google.com/maps/documentation/urls/android-intents
 * */

public class MainActivity extends AppCompatActivity {
    private String providerId = LocationManager.GPS_PROVIDER;
    private Geocoder geo = null;
    private LocationManager locationManager = null;
    private static final int MIN_DIST = 20;
    private static final int MIN_PERIOD = 30000;
    Location mLocation;

    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {
            // attivo GPS su dispositivo
            updateText(R.id.enabled, "TRUE");
        }

        @Override
        public void onProviderDisabled(String provider) {
            // disattivo GPS su dispositivo
            updateText(R.id.enabled, "FALSE");
        }

        @Override
        public void onLocationChanged(Location location) {
            updateGUI(location);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
        geo = new Geocoder(this, Locale.getDefault());
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Location location = locationManager.getLastKnownLocation(providerId);

        if (location != null)
            updateGUI(location);
        if (locationManager != null && locationManager.isProviderEnabled(providerId))
            updateText(R.id.enabled, "TRUE");
        else
            updateText(R.id.enabled, "FALSE");
        locationManager.requestLocationUpdates(providerId, MIN_PERIOD, MIN_DIST, locationListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (locationManager != null && locationManager.isProviderEnabled(providerId))
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.removeUpdates(locationListener);
    }

    private void updateGUI(Location location)
    {
        Date timestamp = new Date(location.getTime());
        updateText(R.id.timestamp, timestamp.toString());
        double latitude = location.getLatitude();
        updateText(R.id.latitude, String.valueOf(latitude));
        double longitude = location.getLongitude();
        updateText(R.id.longitude, String.valueOf(longitude));
        new AddressSolver().execute(location);
        mLocation = location;
    }

    private void updateText(int id, String text)
    {
        TextView textView = (TextView) findViewById(id);
        textView.setText(text);
    }

    public void getLocaltionName(View view) {
        if(mLocation!=null) {
            Toast.makeText(this, "getting location", Toast.LENGTH_LONG).show();
            new AddressSolver().execute(mLocation);
        } else {
            Toast.makeText(this, "errore", Toast.LENGTH_LONG).show();
        }
    }

    public void getGoToLocation(View view) {
        // Creates an Intent that will load a map of San Francisco
//		Uri gmmIntentUri = Uri.parse("geo:37.7749,-122.4194");
        //Uri gmmIntentUri = Uri.parse("geo:"+ mLocation.getLatitude() +","+ mLocation.getLongitude() +"?q=farmacia");
        Uri gmmIntentUri = Uri.parse("geo:"+ mLocation.getLatitude() +","+ mLocation.getLongitude() );
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    public void getGoToLocation2(View view) {
        String latStr = ""+((EditText)findViewById(R.id.my_lat)).getText();
        String lngStr = ""+((EditText)findViewById(R.id.my_lng)).getText();

        //Uri gmmIntentUri = Uri.parse("geo:"+ latStr +","+ lngStr );
        //Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        //mapIntent.setPackage("com.google.android.apps.maps");
        //startActivity(mapIntent);

        /*
        Uri u = Uri.parse("http://ansa.it" );
        Intent i = new Intent(Intent.ACTION_VIEW, u);
        try {
            startActivity(i);
        } catch(Exception e){
            Toast.makeText(this, "Non ho trovato un app per visualizzare:\n"+u, Toast.LENGTH_LONG).show();
            //Uri u2 = Uri.parse("https://play.google.com/store/apps/datails?id=com.google.android.youtube" );
            Uri u2 = Uri.parse("market://details?id=com.google.android.youtube" );
            Intent i2 = new Intent(Intent.ACTION_VIEW, u2);
            startActivity(i2);
        }
        */
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + "187"));
        startActivity(intent);
    }


    private class AddressSolver extends AsyncTask<Location, Void, String>
    {

        @Override
        protected String doInBackground(Location... params)
        {
            Location pos=params[0];
            double latitude = pos.getLatitude();
            double longitude = pos.getLongitude();
            Log.d("MY_GPS", "getAltitude: "+pos.getAltitude());
            Log.d("MY_GPS", "getAccuracy: "+pos.getAccuracy());
            Log.d("MY_GPS", "getSpeed: "+pos.getSpeed());

            List<Address> addresses = null;
            try
            {
                addresses = geo.getFromLocation(latitude, longitude, 1);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            if (addresses!=null)
            {
                if (addresses.isEmpty())
                {
                    return null;
                }
                else {
                    if (addresses.size() > 0)
                    {
                        //
                        String a = "";
                        Address tmp=addresses.get(0);
                        System.out.println("tmp: "+ tmp);
                        a += tmp.getLocality();
                        a += "\n"+ tmp.getCountryName();
                        a += "\n"+ tmp.getSubLocality();
                        a += "\n"+ tmp.getAddressLine(0);
//						 for (int y=0;y<tmp.getMaxAddressLineIndex();y++) {
//							 a += (tmp.getAddressLine(y)+"\n");
//							 System.out.println("tmp.getAddressLine(y): "+ tmp.getAddressLine(y));
//						 }

                        return a;
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result)
        {
            if (result!=null)
                updateText(R.id.where, result);
            else
                updateText(R.id.where, "N.A.");

        }
    }
}
